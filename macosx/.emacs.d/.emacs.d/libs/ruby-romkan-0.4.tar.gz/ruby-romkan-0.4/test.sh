#! /bin/sh

ruby -I. -Ke test.rb </dev/null
